package org.robotframework.swing.slider;

public interface SliderOperator {
    int getValue();
    void setValue(int value);
}
