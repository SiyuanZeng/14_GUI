package org.robotframework.swing.testapp;

import javax.swing.JToggleButton;

public class TestToggleButton extends JToggleButton {
    public TestToggleButton() {
        super("Test Toggle Button");
        setName("testToggleButton");
    }
}
