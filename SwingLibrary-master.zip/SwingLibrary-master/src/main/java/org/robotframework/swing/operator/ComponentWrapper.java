package org.robotframework.swing.operator;

import java.awt.Component;

public interface ComponentWrapper {
    Component getSource();
}
