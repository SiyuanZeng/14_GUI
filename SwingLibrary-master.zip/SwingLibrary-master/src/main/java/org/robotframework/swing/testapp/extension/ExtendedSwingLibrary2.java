package org.robotframework.swing.testapp.extension;


public class ExtendedSwingLibrary2 extends ExtendedSwingLibrary {
}
