
public class TestSwingLibrary extends org.robotframework.swing.SwingLibrary {

    public TestSwingLibrary() {
        super("org/robotframework/swing/testkeyword/**/*.class");
    }
    
}
