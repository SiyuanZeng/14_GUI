ToDo-List
=========

Demo Projct of my article about the [FEST](http://fest.easytesting.org/) Gui Testing tool. 
The corresponding article you find [here](http://www.slideshare.net/DominikDary/functional-tests-withthefestframework).

Project Details:
----------------
This eclipse project contains a little swing sample application 
(com.capgeminisdm.todolist.client.application.ToDoListApplication)
to show the usage of gui testframework
FEST.

FEST homepage:
http://fest.easytesting.org/

The unit test of kernel is located in folder:
test/junit/src

The Fest gui test is located in folder:
test/gui/src

Both testcases can be started using the JUnit4 Testrunner.

For further questions:

Dominik Dary
E-Mail: ddary (AAATTTT) acm.org

