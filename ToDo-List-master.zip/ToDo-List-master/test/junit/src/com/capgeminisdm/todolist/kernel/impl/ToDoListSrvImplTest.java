/*
CapgeminiSdmFestSample Application File
User: ddary
$Date: 2007/07/13 08:17:07 $
$Revision: 1.1 $
*/
package com.capgeminisdm.todolist.kernel.impl;

import junit.framework.TestCase;

import org.junit.Test;

import com.capgeminisdm.todolist.kernel.ToDoListSrv;
import com.capgeminisdm.todolist.kernel.impl.ToDoListSrvImpl;

/**
 * Test of the default Calculator implementation.
 *
 * @author <a href="mailto:dominik.dary@capgemini-sdm.com">Dominik Dary</a>
 *
 */
public class ToDoListSrvImplTest extends TestCase {
   ToDoListSrv toDoListSrv = null;

   public ToDoListSrvImplTest() {
      
   }

   /**
    * Test method for {@link com.capgeminisdm.todolist.kernel.impl.ToDoListSrvImpl#multiply(java.lang.Integer, java.lang.Integer)}.
    */
   @Test
   public void testMultiply() {

   }

   /**
    * Test method for {@link com.capgeminisdm.todolist.kernel.impl.ToDoListSrvImpl#sum(java.lang.Integer, java.lang.Integer)}.
    */
   @Test
   public void testSum() {
   }

}
